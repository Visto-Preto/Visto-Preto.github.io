#!/data/data/com.termux/files/usr/bin/env bash
clear
rm -Rf /data/data/com.termux/files/usr/share/ipcheck
rm -Rf /data/data/com.termux/files/usr/bin/ipcheck
echo ''
echo 'Ip-Check desinstalado'
echo ''
