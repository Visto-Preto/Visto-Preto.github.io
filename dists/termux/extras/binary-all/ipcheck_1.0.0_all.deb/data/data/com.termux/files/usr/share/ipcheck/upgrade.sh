clear
rm -Rf /data/data/com.termux/files/usr/share/ipcheck
rm -Rf /data/data/com.termux/files/usr/bin/ipcheck
echo ''
echo 'Ip-Check desinstalado'
echo ''
curl -sLf https://raw.githubusercontent.com/Visto-Preto/Ip-Check/master/install.sh | bash
